if (isNaN(a)){
  alert('Por favor digite somente numeros')
  inputA.focus()
}
if (isNaN(b)){
  alert('Por favor digite somente numeros')
  inputB.focus()
}